References:

http://astrometry.net/doc/readme.html
https://portal.nersc.gov/project/cosmo/temp/dstn/index-5200/
https://pypi.org/project/astrometry/
